package dk.aau.cs.ds303e18.p3warehouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P3WarehouseApplication {

	public static void main(String[] args) {
		SpringApplication.run(P3WarehouseApplication.class, args);
	}
}
