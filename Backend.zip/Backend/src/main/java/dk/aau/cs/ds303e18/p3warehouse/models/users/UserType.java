package dk.aau.cs.ds303e18.p3warehouse.models.users;

public enum UserType {
    CLIENT,
    PUBLISHER,
    EMPLOYEE
}
