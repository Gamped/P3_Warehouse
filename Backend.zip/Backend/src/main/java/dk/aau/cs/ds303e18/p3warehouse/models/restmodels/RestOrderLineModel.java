package dk.aau.cs.ds303e18.p3warehouse.models.restmodels;

import dk.aau.cs.ds303e18.p3warehouse.models.warehouse.Product;

public class RestOrderLineModel {
    private RestProductModel restProductModel;
    private int amount;
}
