package dk.aau.cs.ds303e18.p3warehouse.exceptions;

public class OrderNotFoundException extends RuntimeException {
}
