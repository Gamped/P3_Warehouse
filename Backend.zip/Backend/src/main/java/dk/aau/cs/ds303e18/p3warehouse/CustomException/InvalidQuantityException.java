package dk.aau.cs.ds303e18.p3warehouse.CustomException;


public class InvalidQuantityException extends Exception {

    public InvalidQuantityException(String s){
        super(s);
    }

}
