package dk.aau.cs.ds303e18.p3warehouse.models.restmodels;

public class RestPublisherModel extends RestCustomerModel{
}
